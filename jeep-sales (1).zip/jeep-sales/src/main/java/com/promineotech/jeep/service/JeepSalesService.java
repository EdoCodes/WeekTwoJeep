package com.promineotech.jeep.service;

public interface JeepSalesService {

}

package com.promineotech.jeep.service;

import org.springframework.stereotype.Service;

@Service
public class DefaultJeepSalesService implements JeepSalesService {

}
